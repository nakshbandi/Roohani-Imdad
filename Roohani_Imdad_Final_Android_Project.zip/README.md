# Roohani Imdad E-Raseed — Final Android Project
Features: Admin/Collector login, donation entry, automatic receipt numbering, Zakat/Lillah/Sadqa/General Imdad/Other, search, daily/monthly/all-time reports, donor history, print/PDF, WhatsApp share, JSON backup/export and restore.
Demo Admin: admin / 1234
Demo Collector: collector / 1234
This version stores data locally on the device. Online multi-device sync should be added only after connecting a real backend (Firebase/Supabase) and changing credentials.
