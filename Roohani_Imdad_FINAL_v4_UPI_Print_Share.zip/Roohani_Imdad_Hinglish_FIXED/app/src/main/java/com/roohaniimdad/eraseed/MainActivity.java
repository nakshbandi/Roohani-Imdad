package com.roohaniimdad.eraseed;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle b){super.onCreate(b);webView=new WebView(this);webView.setLayerType(View.LAYER_TYPE_HARDWARE,null);WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);webView.addJavascriptInterface(new Bridge(),"Android");webView.setWebViewClient(new WebViewClient());setContentView(webView);webView.loadUrl("file:///android_asset/index.html");}
    public class Bridge {
        @JavascriptInterface public void printReceipt(String text){try{File pdf=createReceiptPdf(text);Uri uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",pdf);Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(uri,"application/pdf");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Open / Print Receipt PDF"));}catch(Exception e){shareText("PDF creation failed: "+e.getMessage());}}
        @JavascriptInterface public void shareReceiptImage(String text){try{File image=createReceiptImage(text);Uri uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",image);Intent i=new Intent(Intent.ACTION_SEND);i.setType("image/png");i.putExtra(Intent.EXTRA_STREAM,uri);i.putExtra(Intent.EXTRA_TEXT,text);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_DOCUMENT);i.setClipData(ClipData.newRawUri("receipt",uri));startActivity(Intent.createChooser(i,"Share Receipt Image"));}catch(Exception e){shareText(text);}}
        @JavascriptInterface public void openUpiPayment(String pa,String pn,double amount,String note){try{String q="upi://pay?pa="+enc(pa)+"&pn="+enc(pn)+"&am="+String.format(java.util.Locale.US,"%.2f",amount)+"&cu=INR&tn="+enc(note);Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(q));startActivity(Intent.createChooser(i,"Pay with UPI"));}catch(Exception e){shareText("UPI app not available. UPI ID: "+pa);}}
        @JavascriptInterface public void share(String text){shareText(text);}
    }
    private String enc(String s){try{return URLEncoder.encode(s==null?"":s,StandardCharsets.UTF_8.toString());}catch(Exception e){return "";}}
    private void shareText(String text){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(i,"Share Receipt"));}
    private void drawLogo(Canvas c,float cx,float cy,float radius){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(0xFFE1F1E9);c.drawCircle(cx,cy,radius,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(0xFF087443);c.drawCircle(cx,cy,radius,p);p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));p.setTextSize(radius*.62f);p.setTextAlign(Paint.Align.CENTER);c.drawText("RI",cx,cy+radius*.22f,p);}
    private File createReceiptImage(String text)throws Exception{int width=1200;String[] lines=text.split("\\n");int lineH=58;int height=Math.max(980,260+lines.length*lineH);Bitmap bmp=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(bmp);c.drawColor(0xFFF4F8F6);Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(0xFF087443);c.drawRect(0,0,width,150,p);drawLogo(c,width-95,75,48);p.setColor(0xFFFFFFFF);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));p.setTextAlign(Paint.Align.LEFT);p.setTextSize(48);c.drawText("Roohani Imdad",55,70,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(28);c.drawText("Donation E-Raseed",55,112,p);p.setColor(0xFFFFFFFF);c.drawRoundRect(35,175,width-35,height-35,28,28,p);p.setColor(0xFF17352A);p.setTextSize(32);float y=245;for(String line:lines){if(line.startsWith("Amount:")){p.setColor(0xFF087443);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));}else{p.setColor(0xFF17352A);p.setTypeface(Typeface.DEFAULT);}c.drawText(line,75,y,p);y+=lineH;}p.setColor(0xFFD7E5DE);c.drawRect(75,y+5,width-75,y+8,p);p.setColor(0xFF65736D);p.setTypeface(Typeface.DEFAULT);p.setTextSize(26);c.drawText("JazakAllah Khair.",75,y+55,p);File dir=new File(getCacheDir(),"receipts");if(!dir.exists())dir.mkdirs();File out=new File(dir,"roohani_receipt_"+System.currentTimeMillis()+".png");try(FileOutputStream fos=new FileOutputStream(out)){bmp.compress(Bitmap.CompressFormat.PNG,100,fos);}bmp.recycle();return out;}
    private File createReceiptPdf(String text)throws Exception{PdfDocument doc=new PdfDocument();Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(595,842,1).create();PdfDocument.Page page=doc.startPage(info);Canvas c=page.getCanvas();p.setColor(0xFFF4F8F6);c.drawColor(p.getColor());p.setColor(0xFF087443);c.drawRoundRect(20,20,575,125,18,18,p);drawLogo(c,525,72,32);p.setColor(0xFFFFFFFF);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));p.setTextAlign(Paint.Align.LEFT);p.setTextSize(27);c.drawText("Roohani Imdad",45,65,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(16);c.drawText("Donation E-Raseed",45,92,p);p.setColor(0xFFFFFFFF);c.drawRoundRect(25,145,570,815,18,18,p);p.setColor(0xFF17352A);p.setTextSize(15);float y=190;for(String line:text.split("\\n")){if(line.startsWith("Amount:")){p.setColor(0xFF087443);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));}else{p.setColor(0xFF17352A);p.setTypeface(Typeface.DEFAULT);}c.drawText(line,50,y,p);y+=30;if(y>755)break;}p.setColor(0xFF65736D);p.setTypeface(Typeface.DEFAULT);p.setTextSize(12);c.drawText("JazakAllah Khair.",50,790,p);doc.finishPage(page);File dir=new File(getCacheDir(),"receipts");if(!dir.exists())dir.mkdirs();File out=new File(dir,"roohani_receipt_"+System.currentTimeMillis()+".pdf");try(FileOutputStream fos=new FileOutputStream(out)){doc.writeTo(fos);}doc.close();return out;}
    @Override public void onBackPressed(){if(webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
