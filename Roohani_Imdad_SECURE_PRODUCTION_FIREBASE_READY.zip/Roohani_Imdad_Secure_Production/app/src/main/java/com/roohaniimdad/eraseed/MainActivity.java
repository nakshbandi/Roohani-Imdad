package com.roohaniimdad.eraseed;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.view.View;
import android.content.ClipData;
import android.content.Intent;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import android.util.Base64;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.functions.FirebaseFunctions;
import com.google.firebase.functions.HttpsCallableResult;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView webView;
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private FirebaseFunctions functions;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        auth=FirebaseAuth.getInstance();
        db=FirebaseFirestore.getInstance();
        functions=FirebaseFunctions.getInstance("asia-south1");
        webView=new WebView(this);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE,null);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        webView.addJavascriptInterface(new Bridge(),"Android");
        webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView); webView.loadUrl("file:///android_asset/index.html");
    }

    private void js(String code){ runOnUiThread(() -> webView.evaluateJavascript(code,null)); }
    private String q(String s){ return JSONObject.quote(s==null?"":s); }
    private String enc(String s){ try{return URLEncoder.encode(s==null?"":s, StandardCharsets.UTF_8.toString());}catch(Exception e){return "";} }
    private String upiUri(String pa,String pn,double amount,String note){return "upi://pay?pa="+enc(pa)+"&pn="+enc(pn)+"&am="+String.format(java.util.Locale.US,"%.2f",amount)+"&cu=INR&tn="+enc(note);}
    private void fail(String callback,String message){js("window."+callback+"("+q("ERROR:"+message)+")");}

    public class Bridge {
        @JavascriptInterface public void login(String username,String password){
            String u=username==null?"":username.trim().toLowerCase();
            if(!u.matches("[a-z0-9._-]{3,64}")){fail("authResult","Invalid username.");return;}
            String email=u+"@roohaniimdad.app";
            auth.signInWithEmailAndPassword(email,password).addOnSuccessListener(r -> {
                String uid=auth.getCurrentUser().getUid();
                db.document("users/"+uid).get().addOnSuccessListener(doc -> {
                    if(!doc.exists() || !Boolean.TRUE.equals(doc.getBoolean("active"))){auth.signOut();fail("authResult","Account disabled or not configured.");return;}
                    String role=doc.getString("role");
                    if(!"admin".equals(role) && !"collector".equals(role)){auth.signOut();fail("authResult","Invalid account role.");return;}
                    try{JSONObject o=new JSONObject();o.put("uid",uid);o.put("username",doc.getString("username"));o.put("displayName",doc.getString("displayName"));o.put("role",role);js("window.authResult("+q(o.toString())+")");}catch(Exception e){fail("authResult","Login response failed.");}
                }).addOnFailureListener(e->{auth.signOut();fail("authResult",e.getMessage());});
            }).addOnFailureListener(e->fail("authResult","Invalid username or password."));
        }
        @JavascriptInterface public void logout(){auth.signOut();js("window.loggedOut()");}
        @JavascriptInterface public void loadSettings(){
            if(auth.getCurrentUser()==null)return;
            db.document("organization/settings").get().addOnSuccessListener(d->{try{JSONObject o=new JSONObject();o.put("upiId",d.getString("upiId"));o.put("upiName",d.getString("upiName"));js("window.settingsResult("+q(o.toString())+")");}catch(Exception e){fail("settingsResult","Invalid settings.");}}).addOnFailureListener(e->fail("settingsResult",e.getMessage()));
        }
        @JavascriptInterface public void saveSettings(String json){
            if(auth.getCurrentUser()==null){fail("settingsResult","Login required.");return;}
            try{JSONObject o=new JSONObject(json);Map<String,Object> m=new HashMap<>();m.put("upiId",o.optString("upiId").trim());m.put("upiName",o.optString("upiName","Roohani Imdad").trim());m.put("updatedAt",FieldValue.serverTimestamp());db.document("organization/settings").set(m).addOnSuccessListener(v->js("window.settingsSaved()" )).addOnFailureListener(e->fail("settingsResult",e.getMessage()));}catch(Exception e){fail("settingsResult","Invalid settings.");}
        }
        @JavascriptInterface public String generateUpiQr(String pa,String pn,double amount,String note){
            try{if(pa==null||pa.trim().isEmpty()||amount<=0)return "";String data=upiUri(pa,pn,amount,note);int size=360;BitMatrix m=new QRCodeWriter().encode(data,BarcodeFormat.QR_CODE,size,size);Bitmap b=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);for(int x=0;x<size;x++)for(int y=0;y<size;y++)b.setPixel(x,y,m.get(x,y)?0xFF000000:0xFFFFFFFF);ByteArrayOutputStream out=new ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.PNG,100,out);b.recycle();return "data:image/png;base64,"+Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);}catch(Exception e){return "";}
        }
        @JavascriptInterface public void shareUpiQr(String pa,String pn,double amount,String note){
            try{Bitmap qr=makeQrBitmap(pa,pn,amount,note,900);if(qr==null){shareText("UPI QR generate nahi ho saka.");return;}File dir=new File(getCacheDir(),"receipts");if(!dir.exists())dir.mkdirs();File out=new File(dir,"roohani_upi_qr_"+System.currentTimeMillis()+".png");try(FileOutputStream fos=new FileOutputStream(out)){qr.compress(Bitmap.CompressFormat.PNG,100,fos);}qr.recycle();Uri uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",out);Intent i=new Intent(Intent.ACTION_SEND);i.setType("image/png");i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);i.setClipData(ClipData.newRawUri("upi-qr",uri));startActivity(Intent.createChooser(i,"Share UPI QR Only"));}catch(Exception e){shareText("QR sharing failed: "+e.getMessage());}
        }
        @JavascriptInterface public void createReceipt(String json){
            if(auth.getCurrentUser()==null){fail("receiptResult","Login required.");return;}
            try{JSONObject o=new JSONObject(json);Map<String,Object> data=new HashMap<>();data.put("name",o.optString("name"));data.put("mobile",o.optString("mobile"));data.put("amount",o.getDouble("amount"));data.put("type",o.optString("type","Other"));data.put("mode",o.optString("mode","Cash"));data.put("note",o.optString("note"));data.put("paymentConfirmed",o.optBoolean("paymentConfirmed",false));
                functions.getHttpsCallable("createReceipt").call(data).addOnSuccessListener(r->{try{JSONObject out=new JSONObject();out.put("id",((Map<?,?>)r.getData()).get("id"));out.put("no",((Map<?,?>)r.getData()).get("no"));out.put("input",o);js("window.receiptCreated("+q(out.toString())+")");}catch(Exception e){fail("receiptResult","Receipt created but response failed.");}}).addOnFailureListener(e->fail("receiptResult",e.getMessage()));
            }catch(Exception e){fail("receiptResult","Invalid receipt data.");}
        }
        @JavascriptInterface public void loadReceipts(){
            if(auth.getCurrentUser()==null)return;String uid=auth.getCurrentUser().getUid();db.document("users/"+uid).get().addOnSuccessListener(user->{String role=user.getString("role");Task<QuerySnapshot> t="collector".equals(role)?db.collection("receipts").whereEqualTo("collectorId",uid).get():db.collection("receipts").get();t.addOnSuccessListener(MainActivity.this::sendReceipts).addOnFailureListener(e->fail("receiptsResult",e.getMessage()));});
        }
        private void sendReceipts(QuerySnapshot qs){try{JSONArray a=new JSONArray();for(DocumentSnapshot d:qs.getDocuments()){JSONObject o=new JSONObject();o.put("id",d.getId());o.put("no",d.getString("no"));o.put("name",d.getString("name"));o.put("mobile",d.getString("mobile"));o.put("amount",d.getDouble("amount"));o.put("type",d.getString("type"));o.put("mode",d.getString("mode"));o.put("note",d.getString("note"));o.put("status",d.getString("status"));o.put("collectorId",d.getString("collectorId"));o.put("collectorUsername",d.getString("collectorUsername"));Object ts=d.getTimestamp("date");o.put("date",ts==null?System.currentTimeMillis():ts.toDate().getTime());a.put(o);}js("window.receiptsResult("+q(a.toString())+")");}catch(Exception e){fail("receiptsResult","Receipt parsing failed.");}}
        @JavascriptInterface public void deleteReceipt(String id){functions.getHttpsCallable("deleteReceipt").call(Collections.singletonMap("id",id)).addOnSuccessListener(r->js("window.deleteResult('OK')")).addOnFailureListener(e->fail("deleteResult",e.getMessage()));}
        @JavascriptInterface public void restoreBackup(String json){try{JSONObject o=new JSONObject(json);JSONArray a=o.getJSONArray("rows");ArrayList<Map<String,Object>> rows=new ArrayList<>();for(int i=0;i<a.length();i++){JSONObject r=a.getJSONObject(i);Map<String,Object> m=new HashMap<>();m.put("no",r.optString("no"));m.put("name",r.optString("name"));m.put("mobile",r.optString("mobile"));m.put("amount",r.optDouble("amount"));m.put("type",r.optString("type"));m.put("mode",r.optString("mode"));m.put("note",r.optString("note"));m.put("collectorId",r.optString("collectorId"));m.put("collectorUsername",r.optString("collectorUsername"));m.put("date",r.optString("date"));rows.add(m);}Map<String,Object> data=new HashMap<>();data.put("rows",rows);functions.getHttpsCallable("restoreBackup").call(data).addOnSuccessListener(r->js("window.restoreResult('OK')")).addOnFailureListener(e->fail("restoreResult",e.getMessage()));}catch(Exception e){fail("restoreResult","Invalid backup file.");}}
        @JavascriptInterface public void createCollector(String json){try{JSONObject o=new JSONObject(json);Map<String,Object> m=new HashMap<>();m.put("username",o.optString("username"));m.put("displayName",o.optString("displayName"));m.put("password",o.optString("password"));functions.getHttpsCallable("createCollector").call(m).addOnSuccessListener(r->js("window.collectorResult('OK')")).addOnFailureListener(e->fail("collectorResult",e.getMessage()));}catch(Exception e){fail("collectorResult","Invalid collector data.");}}
        @JavascriptInterface public void loadCollectors(){db.collection("users").whereEqualTo("role","collector").get().addOnSuccessListener(qs->{try{JSONArray a=new JSONArray();for(DocumentSnapshot d:qs){JSONObject o=new JSONObject();o.put("uid",d.getId());o.put("username",d.getString("username"));o.put("displayName",d.getString("displayName"));o.put("active",Boolean.TRUE.equals(d.getBoolean("active")));a.put(o);}js("window.collectorsResult("+q(a.toString())+")");}catch(Exception e){fail("collectorsResult","Collector data failed.");}}).addOnFailureListener(e->fail("collectorsResult",e.getMessage()));}
        @JavascriptInterface public void disableCollector(String uid,boolean enable){String fn=enable?"enableCollector":"disableCollector";functions.getHttpsCallable(fn).call(Collections.singletonMap("uid",uid)).addOnSuccessListener(r->js("window.collectorActionResult('OK')")).addOnFailureListener(e->fail("collectorActionResult",e.getMessage()));}
        @JavascriptInterface public void resetCollectorPassword(String uid,String password){Map<String,Object> m=new HashMap<>();m.put("uid",uid);m.put("password",password);functions.getHttpsCallable("resetCollectorPassword").call(m).addOnSuccessListener(r->js("window.collectorActionResult('OK')")).addOnFailureListener(e->fail("collectorActionResult",e.getMessage()));}
        @JavascriptInterface public void changePassword(String current,String next){
            if(auth.getCurrentUser()==null){fail("passwordResult","Login required.");return;}String email=auth.getCurrentUser().getEmail();if(email==null){fail("passwordResult","Invalid account.");return;}
            auth.getCurrentUser().reauthenticate(EmailAuthProvider.getCredential(email,current)).addOnSuccessListener(x->auth.getCurrentUser().updatePassword(next).addOnSuccessListener(v->js("window.passwordResult('OK')")).addOnFailureListener(e->fail("passwordResult",e.getMessage()))).addOnFailureListener(e->fail("passwordResult","Current password is incorrect."));
        }
        @JavascriptInterface public void shareReceiptImage(String text,String pa,String pn,double amount,String note){try{File image=createReceiptImage(text,pa,pn,amount,note);shareFile(image,"image/png","Share Receipt Image");}catch(Exception e){shareText(text);}}
        @JavascriptInterface public void share(String text){shareText(text);}
    }

    private Bitmap makeQrBitmap(String pa,String pn,double amount,String note,int size){try{String q=upiUri(pa,pn,amount,note);BitMatrix m=new QRCodeWriter().encode(q,BarcodeFormat.QR_CODE,size,size);Bitmap b=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);for(int x=0;x<size;x++)for(int y=0;y<size;y++)b.setPixel(x,y,m.get(x,y)?0xFF000000:0xFFFFFFFF);return b;}catch(Exception e){return null;}}
    private void shareFile(File file,String type,String chooser){Uri uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",file);Intent i=new Intent(Intent.ACTION_SEND);i.setType(type);i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);i.setClipData(ClipData.newRawUri("file",uri));startActivity(Intent.createChooser(i,chooser));}
    private void shareText(String text){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(i,"Share"));}
    private void drawLogo(Canvas c,float cx,float cy,float radius){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(0xFFE1F1E9);c.drawCircle(cx,cy,radius,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(0xFF087443);c.drawCircle(cx,cy,radius,p);p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));p.setTextSize(radius*.62f);p.setTextAlign(Paint.Align.CENTER);c.drawText("RI",cx,cy+radius*.22f,p);}
    private File createReceiptImage(String text,String pa,String pn,double amount,String note)throws Exception{
        int width=1200,qrSize=(pa!=null&&!pa.isEmpty()&&amount>0)?360:0;String[] lines=text.split("\\n");int height=Math.max(1080,330+lines.length*58+(qrSize>0?qrSize+90:0));Bitmap bmp=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(bmp);c.drawColor(0xFFF4F8F6);Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(0xFF087443);c.drawRect(0,0,width,150,p);drawLogo(c,width-95,75,48);p.setColor(Color.WHITE);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));p.setTextAlign(Paint.Align.LEFT);p.setTextSize(48);c.drawText("Roohani Imdad",55,70,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(28);c.drawText("Donation E-Raseed",55,112,p);p.setColor(Color.WHITE);c.drawRoundRect(35,175,width-35,height-35,28,28,p);p.setColor(0xFF17352A);p.setTextSize(32);float y=245;for(String line:lines){if(line.startsWith("Amount:")){p.setColor(0xFF087443);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));}else{p.setColor(0xFF17352A);p.setTypeface(Typeface.DEFAULT);}c.drawText(line,75,y,p);y+=58;}if(qrSize>0){Bitmap qr=makeQrBitmap(pa,pn,amount,note,qrSize);if(qr!=null){p.setColor(0xFFEFF8F3);c.drawRoundRect(55,y+18,width-55,y+qrSize+62,22,22,p);float left=(width-qrSize)/2f;c.drawBitmap(qr,left,y+30,p);qr.recycle();p.setColor(0xFF087443);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));p.setTextAlign(Paint.Align.CENTER);p.setTextSize(25);c.drawText("Scan & Pay via UPI",width/2f,y+qrSize+50,p);p.setTextAlign(Paint.Align.LEFT);y+=qrSize+85;}}
        p.setColor(0xFFD7E5DE);c.drawRect(75,y+5,width-75,y+8,p);p.setColor(0xFF65736D);p.setTypeface(Typeface.DEFAULT);p.setTextSize(25);c.drawText("جَزَاكَ ٱللَّٰهُ خَيْرًا",75,y+52,p);p.setTextSize(22);c.drawText("Aap ki di hui raqam kisi bhi nek aur jaiz kaamon mein kharch ki ja sakti hai.",75,y+88,p);
        File dir=new File(getCacheDir(),"receipts");if(!dir.exists())dir.mkdirs();File out=new File(dir,"roohani_receipt_"+System.currentTimeMillis()+".png");try(FileOutputStream fos=new FileOutputStream(out)){bmp.compress(Bitmap.CompressFormat.PNG,100,fos);}bmp.recycle();return out;
    }
    @Override public void onBackPressed(){if(webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
