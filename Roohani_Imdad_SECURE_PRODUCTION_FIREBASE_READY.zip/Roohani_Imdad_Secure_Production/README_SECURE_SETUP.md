# Roohani Imdad E-Raseed — Secure Production Build

This build replaces localStorage passwords and local-only donation data with Firebase Authentication + Cloud Firestore + callable Cloud Functions.

## Before the APK can work
1. Create a Firebase project.
2. Register Android app package: `com.roohaniimdad.eraseed`.
3. Download `google-services.json` into `app/`.
4. Enable Firebase Authentication → Email/Password.
5. Create Cloud Firestore in production/locked mode.
6. Deploy `firestore.rules` and `functions/`.
7. Create the first Admin account in Firebase Authentication, then run the bootstrap function/claim setup described in `functions/README.md`.

The Firebase Android config file contains project identifiers, not service-account credentials. Never put a Firebase Admin service-account JSON or private key inside the APK.

## Roles
- Admin: all collectors, all receipts, UPI settings, reports, backup/restore, delete, collector create/disable/reset.
- Collector: own receipts only, cash receipt, UPI QR → pending → payment confirmation → receipt. Cannot change UPI settings or access another collector's data.

## Important
There is intentionally **no default Admin/Collector password** in this production build. Authentication is server-backed.
