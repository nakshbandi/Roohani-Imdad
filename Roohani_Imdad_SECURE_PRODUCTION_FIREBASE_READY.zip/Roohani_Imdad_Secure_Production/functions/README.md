# Secure backend functions

Deploy these with Firebase CLI after connecting the folder to your Firebase project.

The first Admin account must be created in Firebase Authentication. Then call `bootstrapAdmin` once using a trusted environment (or temporarily add the UID in the function and deploy once). Do not expose admin credentials or service-account keys in the APK.
