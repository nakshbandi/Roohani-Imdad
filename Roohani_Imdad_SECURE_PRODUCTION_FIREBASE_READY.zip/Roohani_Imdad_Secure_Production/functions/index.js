const {onCall, HttpsError} = require('firebase-functions/v2/https');
const {setGlobalOptions} = require('firebase-functions/v2');
const {initializeApp} = require('firebase-admin/app');
const {getAuth} = require('firebase-admin/auth');
const {getFirestore, FieldValue} = require('firebase-admin/firestore');

initializeApp();
setGlobalOptions({region: 'asia-south1', maxInstances: 10});
const db = getFirestore();
const auth = getAuth();

async function requireUser(request) {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Login required.');
  const snap = await db.doc(`users/${request.auth.uid}`).get();
  if (!snap.exists || snap.data().active !== true) throw new HttpsError('permission-denied', 'Account disabled or not configured.');
  return {uid: request.auth.uid, data: snap.data()};
}
async function requireAdmin(request) {
  const u = await requireUser(request);
  if (u.data.role !== 'admin') throw new HttpsError('permission-denied', 'Admin access required.');
  return u;
}
function cleanUsername(v) {
  return String(v || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '');
}
function emailFor(username) { return `${username}@roohaniimdad.app`; }

exports.createCollector = onCall(async (request) => {
  await requireAdmin(request);
  const username = cleanUsername(request.data?.username);
  const displayName = String(request.data?.displayName || username).trim();
  const password = String(request.data?.password || '');
  if (!username || username.length < 3) throw new HttpsError('invalid-argument', 'Username is too short.');
  if (password.length < 8) throw new HttpsError('invalid-argument', 'Password must be at least 8 characters.');
  if (!/^[a-z0-9._-]+$/.test(username)) throw new HttpsError('invalid-argument', 'Invalid username.');
  const email = emailFor(username);
  let user;
  try {
    user = await auth.createUser({email, password, displayName, disabled: false});
  } catch (e) {
    if (e.code === 'auth/email-already-exists') throw new HttpsError('already-exists', 'Username already exists.');
    throw new HttpsError('internal', e.message);
  }
  await auth.setCustomUserClaims(user.uid, {collector: true});
  await db.doc(`users/${user.uid}`).set({username, displayName, role: 'collector', active: true, createdAt: FieldValue.serverTimestamp()});
  await db.collection('audit').add({action: 'collector_created', actorUid: request.auth.uid, targetUid: user.uid, username, at: FieldValue.serverTimestamp()});
  return {uid: user.uid, username, displayName};
});

exports.disableCollector = onCall(async (request) => {
  await requireAdmin(request);
  const uid = String(request.data?.uid || '');
  if (!uid) throw new HttpsError('invalid-argument', 'Collector UID required.');
  const ref = db.doc(`users/${uid}`);
  const snap = await ref.get();
  if (!snap.exists || snap.data().role !== 'collector') throw new HttpsError('not-found', 'Collector not found.');
  await auth.updateUser(uid, {disabled: true});
  await ref.update({active: false, disabledAt: FieldValue.serverTimestamp()});
  await db.collection('audit').add({action: 'collector_disabled', actorUid: request.auth.uid, targetUid: uid, at: FieldValue.serverTimestamp()});
  return {ok: true};
});

exports.enableCollector = onCall(async (request) => {
  await requireAdmin(request);
  const uid = String(request.data?.uid || '');
  if (!uid) throw new HttpsError('invalid-argument', 'Collector UID required.');
  const ref = db.doc(`users/${uid}`);
  const snap = await ref.get();
  if (!snap.exists || snap.data().role !== 'collector') throw new HttpsError('not-found', 'Collector not found.');
  await auth.updateUser(uid, {disabled: false});
  await ref.update({active: true, enabledAt: FieldValue.serverTimestamp()});
  return {ok: true};
});

exports.resetCollectorPassword = onCall(async (request) => {
  await requireAdmin(request);
  const uid = String(request.data?.uid || '');
  const password = String(request.data?.password || '');
  if (!uid || password.length < 8) throw new HttpsError('invalid-argument', 'UID and an 8+ character password are required.');
  const snap = await db.doc(`users/${uid}`).get();
  if (!snap.exists || snap.data().role !== 'collector') throw new HttpsError('not-found', 'Collector not found.');
  await auth.updateUser(uid, {password, disabled: false});
  await db.doc(`users/${uid}`).update({active: true, passwordResetAt: FieldValue.serverTimestamp()});
  await db.collection('audit').add({action: 'collector_password_reset', actorUid: request.auth.uid, targetUid: uid, at: FieldValue.serverTimestamp()});
  return {ok: true};
});

exports.createReceipt = onCall(async (request) => {
  const actor = await requireUser(request);
  const d = request.data || {};
  const name = String(d.name || '').trim();
  const amount = Number(d.amount);
  const type = String(d.type || 'Other');
  const mode = String(d.mode || 'Cash');
  const mobile = String(d.mobile || '').trim();
  const note = String(d.note || '').trim();
  if (!name || !Number.isFinite(amount) || amount <= 0) throw new HttpsError('invalid-argument', 'Donor name and valid amount are required.');
  if (!['Cash','UPI','Bank Transfer','Other'].includes(mode)) throw new HttpsError('invalid-argument', 'Invalid payment mode.');
  if (!['Zakat','Lillah','Sadqa','General Imdad','Other'].includes(type)) throw new HttpsError('invalid-argument', 'Invalid donation type.');
  if (mode === 'UPI' && d.paymentConfirmed !== true) throw new HttpsError('failed-precondition', 'UPI payment must be confirmed before receipt creation.');

  const now = new Date();
  const day = now.toISOString().slice(0,10).replaceAll('-','');
  const counterRef = db.doc(`counters/${day}`);
  const receiptRef = db.collection('receipts').doc();
  const number = await db.runTransaction(async (tx) => {
    const c = await tx.get(counterRef);
    const next = (c.exists ? Number(c.data().next || 1) : 1);
    tx.set(counterRef, {next: next + 1, updatedAt: FieldValue.serverTimestamp()}, {merge: true});
    const no = `RI-${day}-${String(next).padStart(4,'0')}`;
    tx.set(receiptRef, {
      no, name, mobile, amount, type, mode, note,
      status: 'paid', collectorId: actor.uid, collectorUsername: actor.data.username || '',
      date: FieldValue.serverTimestamp(), createdAt: FieldValue.serverTimestamp()
    });
    return no;
  });
  await db.collection('audit').add({action: 'receipt_created', actorUid: request.auth.uid, receiptId: receiptRef.id, receiptNo: number, mode, amount, at: FieldValue.serverTimestamp()});
  return {id: receiptRef.id, no: number};
});

exports.deleteReceipt = onCall(async (request) => {
  await requireAdmin(request);
  const id = String(request.data?.id || '');
  if (!id) throw new HttpsError('invalid-argument', 'Receipt ID required.');
  const ref = db.doc(`receipts/${id}`);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError('not-found', 'Receipt not found.');
  await ref.delete();
  await db.collection('audit').add({action: 'receipt_deleted', actorUid: request.auth.uid, receiptId: id, receiptNo: snap.data().no || '', at: FieldValue.serverTimestamp()});
  return {ok: true};
});

exports.restoreBackup = onCall(async (request) => {
  await requireAdmin(request);
  const rows = Array.isArray(request.data?.rows) ? request.data.rows : [];
  if (!rows.length || rows.length > 500) throw new HttpsError('invalid-argument', 'Backup must contain 1 to 500 receipts.');
  const batch = db.batch();
  let n = 0;
  for (const r of rows) {
    const name = String(r.name || '').trim();
    const amount = Number(r.amount);
    if (!name || !Number.isFinite(amount) || amount <= 0) throw new HttpsError('invalid-argument', 'Invalid receipt in backup.');
    const ref = db.collection('receipts').doc();
    batch.set(ref, {
      no: String(r.no || `RESTORED-${Date.now()}-${++n}`), name,
      mobile: String(r.mobile || ''), amount,
      type: String(r.type || 'Other'), mode: String(r.mode || 'Other'), note: String(r.note || ''),
      status: 'paid', collectorId: String(r.collectorId || request.auth.uid), collectorUsername: String(r.collectorUsername || 'restored'),
      date: r.date ? new Date(r.date) : new Date(), restoredAt: FieldValue.serverTimestamp(), restoredBy: request.auth.uid
    });
  }
  await batch.commit();
  await db.collection('audit').add({action: 'backup_restored', actorUid: request.auth.uid, count: rows.length, at: FieldValue.serverTimestamp()});
  return {ok: true, count: rows.length};
});
