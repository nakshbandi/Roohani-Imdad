package com.roohaniimdad.eraseed;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.view.View;
import android.content.ClipData;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.content.Intent;
import android.content.pm.PackageManager;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import android.util.Base64;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle b){super.onCreate(b);webView=new WebView(this);webView.setLayerType(View.LAYER_TYPE_HARDWARE,null);WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);webView.addJavascriptInterface(new Bridge(),"Android");webView.setWebViewClient(new WebViewClient());webView.setWebChromeClient(new WebChromeClient());setContentView(webView);webView.loadUrl("file:///android_asset/index.html");}
    public class Bridge {
        @JavascriptInterface public void saveReceiptImage(String text,String pa,String pn,double amount,String note){try{File image=createReceiptImage(text,pa,pn,amount,note);ContentValues values=new ContentValues();values.put(MediaStore.Images.Media.DISPLAY_NAME,"Roohani_Receipt_"+System.currentTimeMillis()+".png");values.put(MediaStore.Images.Media.MIME_TYPE,"image/png");values.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Roohani Imdad");Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new Exception("Could not save image");try(java.io.InputStream in=new java.io.FileInputStream(image);java.io.OutputStream out=getContentResolver().openOutputStream(uri)){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);}Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(uri,"image/png");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Open Receipt Image"));}catch(Exception e){shareText("Receipt image save failed: "+e.getMessage());}}
        @JavascriptInterface public void shareReceiptImage(String text,String pa,String pn,double amount,String note){try{File image=createReceiptImage(text,pa,pn,amount,note);Uri uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",image);Intent i=new Intent(Intent.ACTION_SEND);i.setType("image/png");i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_DOCUMENT);i.setClipData(ClipData.newRawUri("receipt",uri));startActivity(Intent.createChooser(i,"Share Receipt Image"));}catch(Exception e){shareText(text);}}
        @JavascriptInterface public String generateUpiQr(String pa,String pn,double amount,String note){try{String q=upiUri(pa,pn,amount,note);int size=360;BitMatrix m=new QRCodeWriter().encode(q,BarcodeFormat.QR_CODE,size,size);Bitmap b=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);for(int x=0;x<size;x++){for(int y=0;y<size;y++){b.setPixel(x,y,m.get(x,y)?0xFF000000:0xFFFFFFFF);}}ByteArrayOutputStream out=new ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.PNG,100,out);b.recycle();return "data:image/png;base64,"+Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);}catch(Exception e){return "";}}
        @JavascriptInterface public void share(String text){shareText(text);}
    }
    private String enc(String s){try{return URLEncoder.encode(s==null?"":s,StandardCharsets.UTF_8.toString());}catch(Exception e){return "";}}
    private String upiUri(String pa,String pn,double amount,String note){return "upi://pay?pa="+enc(pa)+"&pn="+enc(pn)+"&am="+String.format(java.util.Locale.US,"%.2f",amount)+"&cu=INR&tn="+enc(note);}
    private void shareText(String text){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(i,"Share Receipt"));}
    private void drawLogo(Canvas c,float cx,float cy,float radius){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(0xFFE1F1E9);c.drawCircle(cx,cy,radius,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(0xFF087443);c.drawCircle(cx,cy,radius,p);p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));p.setTextSize(radius*.62f);p.setTextAlign(Paint.Align.CENTER);c.drawText("RI",cx,cy+radius*.22f,p);}
    private Bitmap makeQrBitmap(String pa,String pn,double amount,String note,int size){
        try{
            if(pa==null||pa.trim().isEmpty()||amount<=0)return null;
            String q=upiUri(pa,pn,amount,note);
            BitMatrix m=new QRCodeWriter().encode(q,BarcodeFormat.QR_CODE,size,size);
            Bitmap b=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);
            for(int x=0;x<size;x++)for(int y=0;y<size;y++)b.setPixel(x,y,m.get(x,y)?0xFF000000:0xFFFFFFFF);
            return b;
        }catch(Exception e){return null;}
    }
    private File createReceiptImage(String text,String pa,String pn,double amount,String note)throws Exception{
        int width=1200, qrSize=(pa!=null&&!pa.isEmpty()&&amount>0)?360:0;
        String[] lines=text.split("\\n"); int lineH=58;
        int height=Math.max(980,310+lines.length*lineH+(qrSize>0?qrSize+90:0));
        Bitmap bmp=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888); Canvas c=new Canvas(bmp); c.drawColor(0xFFF4F8F6);
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(0xFF087443); c.drawRect(0,0,width,150,p); drawLogo(c,width-95,75,48);
        p.setColor(0xFFFFFFFF); p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD)); p.setTextAlign(Paint.Align.LEFT); p.setTextSize(48); c.drawText("Roohani Imdad",55,70,p);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(28); c.drawText("Donation E-Raseed",55,112,p);
        p.setColor(0xFFFFFFFF); c.drawRoundRect(35,175,width-35,height-35,28,28,p);
        p.setColor(0xFF17352A); p.setTextSize(32); float y=245;
        for(String line:lines){ if(line.startsWith("Amount:")){p.setColor(0xFF087443);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));}else{p.setColor(0xFF17352A);p.setTypeface(Typeface.DEFAULT);} c.drawText(line,75,y,p); y+=lineH; }
        if(qrSize>0){ Bitmap qr=makeQrBitmap(pa,pn,amount,note,qrSize); if(qr!=null){ p.setColor(0xFFEFF8F3); c.drawRoundRect(55,y+18,width-55,y+qrSize+62,22,22,p); float left=(width-qrSize)/2f; c.drawBitmap(qr,left,y+30,p); qr.recycle(); p.setColor(0xFF087443);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));p.setTextAlign(Paint.Align.CENTER);p.setTextSize(25);c.drawText("Scan & Pay via UPI",width/2f,y+qrSize+50,p);p.setTextAlign(Paint.Align.LEFT);y+=qrSize+85; }}
        p.setColor(0xFFD7E5DE); c.drawRect(75,y+5,width-75,y+8,p); p.setColor(0xFF65736D);p.setTypeface(Typeface.DEFAULT);p.setTextSize(26);c.drawText("جَزَاكَ ٱللَّٰهُ خَيْرًا",75,y+55,p); p.setTextSize(22); c.drawText("Aap ki di hui raqam kisi bhi neik aur jaiz kaamo me kharch kiya ja sakta hai.",75,y+90,p);
        File dir=new File(getCacheDir(),"receipts");if(!dir.exists())dir.mkdirs();File out=new File(dir,"roohani_receipt_"+System.currentTimeMillis()+".png"); try(FileOutputStream fos=new FileOutputStream(out)){bmp.compress(Bitmap.CompressFormat.PNG,100,fos);} bmp.recycle(); return out;
    }
    @Override public void onBackPressed(){if(webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
