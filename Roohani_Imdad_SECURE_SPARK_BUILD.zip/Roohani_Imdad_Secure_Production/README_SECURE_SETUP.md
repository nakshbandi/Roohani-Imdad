# Roohani Imdad E-Raseed — Spark/Free Secure Build

This build uses Firebase Authentication + Cloud Firestore + Firestore Security Rules.
It intentionally does **not** deploy Cloud Functions, because Cloud Functions deployment requires the Blaze plan.

## Firebase setup
1. Register Android package: `com.roohaniimdad.eraseed`.
2. Put the downloaded `google-services.json` in `app/`.
3. Enable Authentication > Email/Password.
4. Create Firestore `(default)` in production mode.
5. Publish `firestore/firestore.rules`.

## Spark-plan account provisioning
Because this project stays on the free Spark plan, Authentication accounts are provisioned in Firebase Console.

### Admin
- Authentication > Users > Add user.
- Use an email in the app's internal username format: `<username>@roohaniimdad.app`.
- Firestore > `users` > create a document whose ID is the Auth user's UID:
  - `username`: lowercase username
  - `displayName`: display name
  - `role`: `admin`
  - `active`: `true`

### Collector
Create the Auth user in the same way, then create `users/<UID>` with:
- `username`: lowercase username
- `displayName`: collector name
- `role`: `collector`
- `active`: `true`

Admin can enable/disable collector profiles from the app. Authentication password changes are done through Firebase Authentication; the app also supports the logged-in user's own password change.

## Security model
- Collector reads only receipts where `collectorId == auth.uid`.
- Admin reads all receipts.
- Only Admin can delete receipts or change organization UPI settings.
- Collector cannot change UPI settings.
- User role/username cannot be changed through the app.
- Receipt creation is allowed only for the signed-in collector and validates the main fields in Firestore Rules.
- Receipt numbers are collision-resistant client-generated IDs (`RI-YYYYMMDD-XXXXXXXX`) because sequential server-side counters would require a trusted server function.

## UPI
UPI QR is generated on-device. For UPI receipts, the collector confirms that payment has actually been received before creating the receipt. The app does not claim automatic bank/UPI verification.

## Important
No system is absolutely unhackable. The security boundary is Firebase Authentication + Firestore Security Rules. Keep the database in production mode and test rules before release.
