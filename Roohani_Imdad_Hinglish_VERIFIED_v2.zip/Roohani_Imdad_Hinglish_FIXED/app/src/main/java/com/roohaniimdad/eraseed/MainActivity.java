package com.roohaniimdad.eraseed;

import android.app.*;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.content.*;
import android.webkit.*;
import android.view.View;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle b){ super.onCreate(b);
        webView=new WebView(this);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE,null);
        WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        webView.addJavascriptInterface(new Bridge(),"Android");
        webView.setWebViewClient(new WebViewClient());
        setContentView(webView); webView.loadUrl("file:///android_asset/index.html");
    }
    public class Bridge {
        @JavascriptInterface public void printReceipt(String jobName){
            PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
            pm.print(jobName==null?"Roohani Imdad Receipt":jobName, webView.createPrintDocumentAdapter(jobName), new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
        }
        @JavascriptInterface public void share(String text){
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,text); startActivity(Intent.createChooser(i,"Share Receipt"));
        }
    }
    @Override public void onBackPressed(){ if(webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
