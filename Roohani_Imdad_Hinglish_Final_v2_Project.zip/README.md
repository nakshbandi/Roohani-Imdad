# Roohani Imdad E-Raseed — Hinglish Final Build 2.0

Android donation e-receipt app. UI language is Hinglish/English (no Hindi-script labels).

Demo login:
- Admin: admin / 1234
- Collector: collector / 1234

Data is stored locally on the device.
