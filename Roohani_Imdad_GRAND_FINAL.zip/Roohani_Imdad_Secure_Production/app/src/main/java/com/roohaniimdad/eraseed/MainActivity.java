package com.roohaniimdad.eraseed;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.view.View;
import android.content.ClipData;
import android.content.Intent;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import android.util.Base64;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.android.gms.tasks.Task;
import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView webView;
    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        auth=FirebaseAuth.getInstance();
        db=FirebaseFirestore.getInstance();
        webView=new WebView(this);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE,null);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        webView.addJavascriptInterface(new Bridge(),"Android");
        webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView); webView.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                new OnBackInvokedCallback() {
                    @Override public void onBackInvoked() { handleSystemBack(); }
                }
            );
        }
    }

    private void handleSystemBack(){
        webView.evaluateJavascript("(window.handleAndroidBack ? window.handleAndroidBack() : 'EXIT')", value -> {
            if ("\"EXIT\"".equals(value)) MainActivity.super.onBackPressed();
        });
    }

    private void js(String code){ runOnUiThread(() -> webView.evaluateJavascript(code,null)); }
    private String q(String s){ return JSONObject.quote(s==null?"":s); }
    private String enc(String s){ return Uri.encode(s==null?"":s).replace("+","%20"); }
    private String upiUri(String pa,String pn,double amount,String note){
        String vpa=pa==null?"":pa.trim().replace(" ","");
        String payee=pn==null||pn.trim().isEmpty()?"Khidmat":pn.trim();
        String amt=String.format(java.util.Locale.US,"%.2f",amount);
        return "upi://pay?pa="+vpa+"&pn="+enc(payee)+"&am="+amt+"&cu=INR";
    }
    private void fail(String callback,String message){js("window."+callback+"("+q("ERROR:"+message)+")");}

    public class Bridge {
        @JavascriptInterface public void login(String username,String password){
            String u=username==null?"":username.trim().toLowerCase();
            if(!u.matches("[a-z0-9._-]{3,64}")){fail("authResult","Invalid username.");return;}
            String email=u+"@roohaniimdad.app";
            auth.signInWithEmailAndPassword(email,password).addOnSuccessListener(r -> {
                String uid=auth.getCurrentUser().getUid();
                db.document("users/"+uid).get().addOnSuccessListener(doc -> {
                    if(!doc.exists() || !Boolean.TRUE.equals(doc.getBoolean("active"))){auth.signOut();fail("authResult","Account disabled or not configured.");return;}
                    String role=doc.getString("role");
                    if(!"admin".equals(role) && !"collector".equals(role)){auth.signOut();fail("authResult","Invalid account role.");return;}
                    try{JSONObject o=new JSONObject();o.put("uid",uid);o.put("username",doc.getString("username"));o.put("displayName",doc.getString("displayName"));o.put("role",role);js("window.authResult("+q(o.toString())+")");}catch(Exception e){fail("authResult","Login response failed.");}
                }).addOnFailureListener(e->{auth.signOut();fail("authResult",e.getMessage());});
            }).addOnFailureListener(e->fail("authResult","Invalid username or password."));
        }
        @JavascriptInterface public void logout(){auth.signOut();js("window.loggedOut()");}
        @JavascriptInterface public void loadSettings(){
            if(auth.getCurrentUser()==null)return;
            db.document("organization/settings").get().addOnSuccessListener(d->{try{JSONObject o=new JSONObject();o.put("upiId",d.getString("upiId"));o.put("upiName",d.getString("upiName"));js("window.settingsResult("+q(o.toString())+")");}catch(Exception e){fail("settingsResult","Invalid settings.");}}).addOnFailureListener(e->fail("settingsResult",e.getMessage()));
        }
        @JavascriptInterface public void saveSettings(String json){
            if(auth.getCurrentUser()==null){fail("settingsResult","Login required.");return;}
            try{JSONObject o=new JSONObject(json);Map<String,Object> m=new HashMap<>();m.put("upiId",o.optString("upiId").trim());m.put("upiName",o.optString("upiName","Roohani Imdad").trim());m.put("updatedAt",FieldValue.serverTimestamp());db.document("organization/settings").set(m).addOnSuccessListener(v->js("window.settingsSaved()" )).addOnFailureListener(e->fail("settingsResult",e.getMessage()));}catch(Exception e){fail("settingsResult","Invalid settings.");}
        }
        @JavascriptInterface public String generateUpiQr(String pa,String pn,double amount,String note){
            try{if(pa==null||pa.trim().isEmpty()||amount<=0)return "";String data=upiUri(pa,pn,amount,note);int size=360;BitMatrix m=new QRCodeWriter().encode(data,BarcodeFormat.QR_CODE,size,size);Bitmap b=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);for(int x=0;x<size;x++)for(int y=0;y<size;y++)b.setPixel(x,y,m.get(x,y)?0xFF000000:0xFFFFFFFF);ByteArrayOutputStream out=new ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.PNG,100,out);b.recycle();return "data:image/png;base64,"+Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);}catch(Exception e){return "";}
        }
        @JavascriptInterface public void shareUpiQr(String pa,String pn,double amount,String note){
            try{Bitmap qr=makeQrBitmap(pa,pn,amount,note,900);if(qr==null){shareText("UPI QR generate nahi ho saka.");return;}File dir=new File(getCacheDir(),"receipts");if(!dir.exists())dir.mkdirs();File out=new File(dir,"roohani_upi_qr_"+System.currentTimeMillis()+".png");try(FileOutputStream fos=new FileOutputStream(out)){qr.compress(Bitmap.CompressFormat.PNG,100,fos);}qr.recycle();Uri uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",out);Intent i=new Intent(Intent.ACTION_SEND);i.setType("image/png");i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);i.setClipData(ClipData.newRawUri("upi-qr",uri));startActivity(Intent.createChooser(i,"Share UPI QR Only"));}catch(Exception e){shareText("QR sharing failed: "+e.getMessage());}
        }
        @JavascriptInterface public void createReceipt(String json){
            if(auth.getCurrentUser()==null){fail("receiptResult","Login required.");return;}
            try{
                JSONObject o=new JSONObject(json);
                final String uid=auth.getCurrentUser().getUid();
                db.document("users/"+uid).get().addOnSuccessListener(user->{
                    if(!user.exists() || !Boolean.TRUE.equals(user.getBoolean("active"))){fail("receiptResult","Account disabled or not configured.");return;}
                    String role=user.getString("role");
                    if(!"admin".equals(role) && !"collector".equals(role)){fail("receiptResult","Invalid account role.");return;}
                    String name=o.optString("name").trim(); double amount=o.optDouble("amount",0); String mode=o.optString("mode","Cash");
                    if(name.isEmpty() || !Double.isFinite(amount) || amount<=0){fail("receiptResult","Donor name and valid amount are required.");return;}
                    if("UPI".equals(mode) && !o.optBoolean("paymentConfirmed",false)){fail("receiptResult","UPI payment must be confirmed before receipt creation.");return;}
                    String day=new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US).format(new java.util.Date());
                    String suffix=java.util.UUID.randomUUID().toString().replace("-","").substring(0,8).toUpperCase(java.util.Locale.US);
                    String no="RI-"+day+"-"+suffix;
                    Map<String,Object> r=new HashMap<>();
                    r.put("no",no); r.put("name",name); r.put("mobile",o.optString("mobile").trim()); r.put("amount",amount);
                    r.put("type",o.optString("type","Other")); r.put("mode",mode); r.put("note",o.optString("note").trim());
                    r.put("status","paid"); r.put("collectorId",uid); r.put("collectorUsername",user.getString("username"));
                    r.put("date",FieldValue.serverTimestamp()); r.put("createdAt",FieldValue.serverTimestamp());
                    db.collection("receipts").add(r).addOnSuccessListener(ref->{
                        try{JSONObject out=new JSONObject();out.put("id",ref.getId());out.put("no",no);out.put("input",o);js("window.receiptCreated("+q(out.toString())+")");}
                        catch(Exception e){fail("receiptResult","Receipt created but response failed.");}
                    }).addOnFailureListener(e->fail("receiptResult",e.getMessage()));
                }).addOnFailureListener(e->fail("receiptResult",e.getMessage()));
            }catch(Exception e){fail("receiptResult","Invalid receipt data.");}
        }
        @JavascriptInterface public void loadReceipts(){
            if(auth.getCurrentUser()==null)return;String uid=auth.getCurrentUser().getUid();db.document("users/"+uid).get().addOnSuccessListener(user->{String role=user.getString("role");Task<QuerySnapshot> t="collector".equals(role)?db.collection("receipts").whereEqualTo("collectorId",uid).get():db.collection("receipts").get();t.addOnSuccessListener(qs -> sendReceipts(qs)).addOnFailureListener(e->fail("receiptsResult",e.getMessage()));});
        }
        private void sendReceipts(QuerySnapshot qs){try{JSONArray a=new JSONArray();for(DocumentSnapshot d:qs.getDocuments()){JSONObject o=new JSONObject();o.put("id",d.getId());o.put("no",d.getString("no"));o.put("name",d.getString("name"));o.put("mobile",d.getString("mobile"));o.put("amount",d.getDouble("amount"));o.put("type",d.getString("type"));o.put("mode",d.getString("mode"));o.put("note",d.getString("note"));o.put("status",d.getString("status"));o.put("collectorId",d.getString("collectorId"));o.put("collectorUsername",d.getString("collectorUsername"));com.google.firebase.Timestamp ts=d.getTimestamp("date");o.put("date",ts==null?System.currentTimeMillis():ts.toDate().getTime());a.put(o);}js("window.receiptsResult("+q(a.toString())+")");}catch(Exception e){fail("receiptsResult","Receipt parsing failed.");}}
        @JavascriptInterface public void deleteReceipt(String id){
            if(auth.getCurrentUser()==null){fail("deleteResult","Login required.");return;}
            db.document("users/"+auth.getCurrentUser().getUid()).get().addOnSuccessListener(u->{
                if(!u.exists() || !"admin".equals(u.getString("role")) || !Boolean.TRUE.equals(u.getBoolean("active"))){fail("deleteResult","Admin access required.");return;}
                db.document("receipts/"+id).delete().addOnSuccessListener(v->js("window.deleteResult('OK')")).addOnFailureListener(e->fail("deleteResult",e.getMessage()));
            }).addOnFailureListener(e->fail("deleteResult",e.getMessage()));
        }
        @JavascriptInterface public void restoreBackup(String json){
            if(auth.getCurrentUser()==null){fail("restoreResult","Login required.");return;}
            db.document("users/"+auth.getCurrentUser().getUid()).get().addOnSuccessListener(u->{
                if(!u.exists() || !"admin".equals(u.getString("role")) || !Boolean.TRUE.equals(u.getBoolean("active"))){fail("restoreResult","Admin access required.");return;}
                try{JSONObject o=new JSONObject(json);JSONArray a=o.getJSONArray("rows");if(a.length()<1 || a.length()>450)throw new Exception("Backup must contain 1 to 450 receipts.");
                    com.google.firebase.firestore.WriteBatch batch=db.batch();
                    for(int i=0;i<a.length();i++){JSONObject r=a.getJSONObject(i);Map<String,Object> m=new HashMap<>();m.put("no",r.optString("no","RESTORED-"+System.currentTimeMillis()+"-"+i));m.put("name",r.optString("name"));m.put("mobile",r.optString("mobile"));m.put("amount",r.optDouble("amount"));m.put("type",r.optString("type","Other"));m.put("mode",r.optString("mode","Other"));m.put("note",r.optString("note"));m.put("status","paid");m.put("collectorId",r.optString("collectorId",auth.getCurrentUser().getUid()));m.put("collectorUsername",r.optString("collectorUsername","restored"));m.put("date",FieldValue.serverTimestamp());m.put("restoredBy",auth.getCurrentUser().getUid());batch.set(db.collection("receipts").document(),m);}
                    batch.commit().addOnSuccessListener(v->js("window.restoreResult('OK')")).addOnFailureListener(e->fail("restoreResult",e.getMessage()));
                }catch(Exception e){fail("restoreResult",e.getMessage());}
            }).addOnFailureListener(e->fail("restoreResult",e.getMessage()));
        }
        @JavascriptInterface public void createCollector(String json){
            if(auth.getCurrentUser()==null){fail("collectorResult","Login required.");return;}
            db.document("users/"+auth.getCurrentUser().getUid()).get().addOnSuccessListener(me->{
                if(!me.exists() || !"admin".equals(me.getString("role")) || !Boolean.TRUE.equals(me.getBoolean("active"))){fail("collectorResult","Admin access required.");return;}
                try{
                    JSONObject o=new JSONObject(json); String displayName=o.optString("displayName").trim(); String username=o.optString("username").trim().toLowerCase(); String password=o.optString("password");
                    if(displayName.isEmpty() || displayName.length()>120){fail("collectorResult","Valid collector name required.");return;}
                    if(!username.matches("[a-z0-9._-]{3,64}")){fail("collectorResult","Invalid username.");return;}
                    if(password.length()<8){fail("collectorResult","Password must be at least 8 characters.");return;}
                    db.collection("users").whereEqualTo("username",username).limit(1).get().addOnSuccessListener(existing->{
                        if(!existing.isEmpty()){fail("collectorResult","Ye username already exist karta hai.");return;}
                        new Thread(()->provisionCollector(username,displayName,password)).start();
                    }).addOnFailureListener(e->fail("collectorResult","Username check failed: "+e.getMessage()));
                }catch(Exception e){fail("collectorResult","Invalid collector data.");}
            }).addOnFailureListener(e->fail("collectorResult",e.getMessage()));
        }
        private String firebaseWebApiKey(){
            try{int id=getResources().getIdentifier("google_api_key","string",getPackageName());return id==0?"":getString(id);}catch(Exception e){return "";}
        }
        private String httpPostJson(String endpoint,String body)throws Exception{
            HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection();c.setRequestMethod("POST");c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");
            try(OutputStream os=c.getOutputStream()){os.write(body.getBytes(StandardCharsets.UTF_8));}
            int code=c.getResponseCode();java.io.InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();StringBuilder sb=new StringBuilder();if(in!=null){try(BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=br.readLine())!=null)sb.append(line);}}
            c.disconnect();if(code<200||code>=300)throw new Exception(parseAuthError(sb.toString()));return sb.toString();
        }
        private String parseAuthError(String raw){
            try{JSONObject o=new JSONObject(raw);JSONObject er=o.optJSONObject("error");String msg=er==null?"":er.optString("message");if("EMAIL_EXISTS".equals(msg))return "Ye username already registered hai.";if("WEAK_PASSWORD".equals(msg))return "Password bahut weak hai.";if(!msg.isEmpty())return msg.replace('_',' ');}catch(Exception ignored){}return "Collector account create nahi ho saka.";
        }
        private void provisionCollector(String username,String displayName,String password){
            String key=firebaseWebApiKey();if(key.isEmpty()){fail("collectorResult","Firebase web API key available nahi hai.");return;}
            String email=username+"@roohaniimdad.app";String idToken=null;
            try{
                JSONObject req=new JSONObject();req.put("email",email);req.put("password",password);req.put("returnSecureToken",true);
                JSONObject res=new JSONObject(httpPostJson("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key="+Uri.encode(key),req.toString()));
                String uid=res.optString("localId");idToken=res.optString("idToken");if(uid.isEmpty()||idToken.isEmpty())throw new Exception("Firebase account response incomplete.");
                Map<String,Object> profile=new HashMap<>();profile.put("username",username);profile.put("displayName",displayName);profile.put("role","collector");profile.put("active",true);profile.put("createdAt",FieldValue.serverTimestamp());profile.put("createdBy",auth.getCurrentUser().getUid());
                String finalUid=uid; final String createdToken=idToken;db.document("users/"+finalUid).set(profile).addOnSuccessListener(v->js("window.collectorResult('OK')")).addOnFailureListener(e->{rollbackCreatedAuthUser(createdToken);fail("collectorResult","Profile save failed; account rollback kiya ja raha hai.");});
            }catch(Exception e){fail("collectorResult",e.getMessage());}
        }
        private void rollbackCreatedAuthUser(String idToken){if(idToken==null||idToken.isEmpty())return;String key=firebaseWebApiKey();if(key.isEmpty())return;new Thread(()->{try{JSONObject req=new JSONObject();req.put("idToken",idToken);httpPostJson("https://identitytoolkit.googleapis.com/v1/accounts:delete?key="+Uri.encode(key),req.toString());}catch(Exception ignored){}}).start();}
        @JavascriptInterface public void loadCollectors(){
            if(auth.getCurrentUser()==null)return;
            db.document("users/"+auth.getCurrentUser().getUid()).get().addOnSuccessListener(me->{
                if(!me.exists() || !"admin".equals(me.getString("role"))){fail("collectorsResult","Admin access required.");return;}
                db.collection("users").whereEqualTo("role","collector").get().addOnSuccessListener(qs->{try{JSONArray a=new JSONArray();for(DocumentSnapshot d:qs){JSONObject o=new JSONObject();o.put("uid",d.getId());o.put("username",d.getString("username"));o.put("displayName",d.getString("displayName"));o.put("active",Boolean.TRUE.equals(d.getBoolean("active")));a.put(o);}js("window.collectorsResult("+q(a.toString())+")");}catch(Exception e){fail("collectorsResult","Collector data failed.");}}).addOnFailureListener(e->fail("collectorsResult",e.getMessage()));
            });
        }
        @JavascriptInterface public void disableCollector(String uid,boolean enable){
            if(auth.getCurrentUser()==null){fail("collectorActionResult","Login required.");return;}
            db.document("users/"+auth.getCurrentUser().getUid()).get().addOnSuccessListener(me->{
                if(!me.exists() || !"admin".equals(me.getString("role"))){fail("collectorActionResult","Admin access required.");return;}
                Map<String,Object> m=new HashMap<>();m.put("active",enable);m.put(enable?"enabledAt":"disabledAt",FieldValue.serverTimestamp());
                db.document("users/"+uid).update(m).addOnSuccessListener(v->js("window.collectorActionResult('OK')")).addOnFailureListener(e->fail("collectorActionResult",e.getMessage()));
            });
        }
        @JavascriptInterface public void resetCollectorPassword(String uid,String password){fail("collectorActionResult","Password reset is managed through Firebase Authentication on the Free/Spark plan.");}
        @JavascriptInterface public void changePassword(String current,String next){
            if(auth.getCurrentUser()==null){fail("passwordResult","Login required.");return;}String email=auth.getCurrentUser().getEmail();if(email==null){fail("passwordResult","Invalid account.");return;}
            auth.getCurrentUser().reauthenticate(EmailAuthProvider.getCredential(email,current)).addOnSuccessListener(x->auth.getCurrentUser().updatePassword(next).addOnSuccessListener(v->js("window.passwordResult('OK')")).addOnFailureListener(e->fail("passwordResult",e.getMessage()))).addOnFailureListener(e->fail("passwordResult","Current password is incorrect."));
        }
        @JavascriptInterface public void shareReceiptImage(String text,String pa,String pn,double amount,String note){try{File image=createReceiptImage(text,pa,pn,amount,note);shareFile(image,"image/png","Share Receipt Image");}catch(Exception e){shareText(text);}}
        @JavascriptInterface public void share(String text){shareText(text);}
    }

    private Bitmap makeQrBitmap(String pa,String pn,double amount,String note,int size){try{String q=upiUri(pa,pn,amount,note);BitMatrix m=new QRCodeWriter().encode(q,BarcodeFormat.QR_CODE,size,size);Bitmap b=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);for(int x=0;x<size;x++)for(int y=0;y<size;y++)b.setPixel(x,y,m.get(x,y)?0xFF000000:0xFFFFFFFF);return b;}catch(Exception e){return null;}}
    private void shareFile(File file,String type,String chooser){Uri uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",file);Intent i=new Intent(Intent.ACTION_SEND);i.setType(type);i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);i.setClipData(ClipData.newRawUri("file",uri));startActivity(Intent.createChooser(i,chooser));}
    private void shareText(String text){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(i,"Share"));}
    private void drawLogo(Canvas c,float cx,float cy,float radius){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(0xFFE1F1E9);c.drawCircle(cx,cy,radius,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(0xFF087443);c.drawCircle(cx,cy,radius,p);p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));p.setTextSize(radius*.62f);p.setTextAlign(Paint.Align.CENTER);c.drawText("RI",cx,cy+radius*.22f,p);}
    private File createReceiptImage(String text,String pa,String pn,double amount,String note)throws Exception{
        int width=1200,qrSize=(pa!=null&&!pa.isEmpty()&&amount>0)?360:0;
        java.util.ArrayList<String> cleanLines=new java.util.ArrayList<>();
        for(String line:text.split("\n")){
            String t=line.trim();
            if(t.equals("جَزَاكَ ٱللَّٰهُ خَيْرًا") || t.equals("Aap ki di hui raqam kisi bhi nek aur jaiz kaamon mein kharch ki ja sakti hai.")) continue;
            cleanLines.add(line);
        }
        String[] lines=cleanLines.toArray(new String[0]);
        int height=Math.max(1080,330+lines.length*58+(qrSize>0?qrSize+90:0));Bitmap bmp=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(bmp);c.drawColor(0xFFF4F8F6);Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(0xFF087443);c.drawRect(0,0,width,150,p);drawLogo(c,width-95,75,48);p.setColor(Color.WHITE);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));p.setTextAlign(Paint.Align.LEFT);p.setTextSize(48);c.drawText("Roohani Imdad",55,70,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(28);c.drawText("Donation E-Raseed",55,112,p);p.setColor(Color.WHITE);c.drawRoundRect(35,175,width-35,height-35,28,28,p);p.setColor(0xFF17352A);p.setTextSize(32);float y=245;for(String line:lines){if(line.startsWith("Amount:")){p.setColor(0xFF087443);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));}else{p.setColor(0xFF17352A);p.setTypeface(Typeface.DEFAULT);}c.drawText(line,75,y,p);y+=58;}if(qrSize>0){Bitmap qr=makeQrBitmap(pa,pn,amount,note,qrSize);if(qr!=null){p.setColor(0xFFEFF8F3);c.drawRoundRect(55,y+18,width-55,y+qrSize+62,22,22,p);float left=(width-qrSize)/2f;c.drawBitmap(qr,left,y+30,p);qr.recycle();p.setColor(0xFF087443);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));p.setTextAlign(Paint.Align.CENTER);p.setTextSize(25);c.drawText("Scan & Pay via UPI",width/2f,y+qrSize+50,p);p.setTextAlign(Paint.Align.LEFT);y+=qrSize+85;}}
        p.setColor(0xFFD7E5DE);c.drawRect(75,y+5,width-75,y+8,p);p.setColor(0xFF65736D);p.setTypeface(Typeface.DEFAULT);p.setTextSize(25);c.drawText("جَزَاكَ ٱللَّٰهُ خَيْرًا",75,y+52,p);p.setTextSize(22);c.drawText("Aap ki di hui raqam kisi bhi nek aur jaiz kaamon mein kharch ki ja sakti hai.",75,y+88,p);
        File dir=new File(getCacheDir(),"receipts");if(!dir.exists())dir.mkdirs();File out=new File(dir,"roohani_receipt_"+System.currentTimeMillis()+".png");try(FileOutputStream fos=new FileOutputStream(out)){bmp.compress(Bitmap.CompressFormat.PNG,100,fos);}bmp.recycle();return out;
    }
    @Override public void onBackPressed(){
        if (Build.VERSION.SDK_INT < 33) handleSystemBack();
    }
}
